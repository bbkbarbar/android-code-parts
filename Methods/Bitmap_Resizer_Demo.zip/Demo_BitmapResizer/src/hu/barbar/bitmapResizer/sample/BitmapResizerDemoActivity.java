package hu.barbar.bitmapResizer.sample;

import hu.barbar.commonObjects.BitmapResizer;
import hu.barbar.commonObjects.BitmapResizer.ResizeParameters;

import java.io.FileNotFoundException;
import java.io.InputStream;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class BitmapResizerDemoActivity extends Activity {
    
	
	private static final int SELECT_PHOTO = 100;
	
	Spinner imageSpinner;
	TextView tv1, tv2, tv3, tv4, tv5, tv6, tvOriginalImg;
	ImageView originalImage, image1, image2, image3, image4, image5, image6;
	Bitmap originalBm;
	int cuttingMode;
	
	
	
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        initUI();
        
        originalBm = ((BitmapDrawable)getResources().getDrawable(R.drawable.test_image_p)).getBitmap();
        
		drawImages();
        
    }
    
    
    private void initUI(){
    	
    	OnItemSelectedListener myOISL = new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int pos, long id) {
				
				switch(pos){
					case 0:{
						originalBm = ((BitmapDrawable)getResources().getDrawable(R.drawable.test_image_l)).getBitmap();
						drawImages();
						break;
					}
					case 1:{
						originalBm = ((BitmapDrawable)getResources().getDrawable(R.drawable.test_image_p)).getBitmap();
						drawImages();
						break;
					}
					case 2:{
						originalBm = ((BitmapDrawable)getResources().getDrawable(R.drawable.test_image_nn)).getBitmap();
						drawImages();
						break;
					}
					case 3:{
						pickImage();
						break;
					}
				}
				
			}

			public void onNothingSelected(AdapterView<?> parent) {}
		};
		
		imageSpinner = (Spinner) findViewById(R.main.imageChooser);
		imageSpinner.setOnItemSelectedListener(myOISL);
    	
    	
    	originalImage = (ImageView) findViewById(R.main.originalImage);
    	
    	tvOriginalImg = (TextView) findViewById(R.main.image_label_original_img);
    	tv1 = (TextView) findViewById(R.main.tv1);
    	tv2 = (TextView) findViewById(R.main.tv2);
    	tv3 = (TextView) findViewById(R.main.tv3);
    	tv4 = (TextView) findViewById(R.main.tv4);
    	tv5 = (TextView) findViewById(R.main.tv5);
    	tv6 = (TextView) findViewById(R.main.tv6);
    	
    	image1 = (ImageView) findViewById(R.main.image1);
    	image2 = (ImageView) findViewById(R.main.image2);
    	image3 = (ImageView) findViewById(R.main.image3);
    	image4 = (ImageView) findViewById(R.main.image4);
    	image5 = (ImageView) findViewById(R.main.image5);
    	image6 = (ImageView) findViewById(R.main.image6);
    	
    }
    
    
    private void pickImage(){
    	
    	Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
    	photoPickerIntent.setType("image/*");
    	startActivityForResult(photoPickerIntent, SELECT_PHOTO);   
    	
    }
    
    
    private void drawImages(){
    	
    	tvOriginalImg.setText(
    			"Original image ("
    			+ Integer.toString(originalBm.getWidth())
    			+ "x"
    			+ Integer.toString(originalBm.getHeight())
    			+ "):"
			);
    	originalImage.setImageBitmap(originalBm);
    	
    	Bitmap bm;
    	
    	BitmapResizer.ResizeParameters rpL = new BitmapResizer.ResizeParameters(320, 150, BitmapResizer.CUT_CENTER);
    	
    	
    	
    	Toast.makeText(
    				getApplicationContext(),
    				rpL.toString(ResizeParameters.MULTILINE),
					1
				).show();
    	
    	bm = BitmapResizer.getResized(originalBm, rpL);
    	tv1.setText("getResized()\nFrame: 320x240\nImage resized: 320x150");
    	image1.setImageBitmap(bm);
    	
    	bm = BitmapResizer.getResized(originalBm, 150, 320);
    	tv2.setText("getResized()\nFrame: 240x320\nImage resized: 150x320");
    	image2.setImageBitmap(bm);
    	
    	bm = BitmapResizer.getResizedToFrame(originalBm, 320, 240);
    	tv3.setText("getResizedToFrame()\nFrame: 320x240");
    	image3.setImageBitmap(bm);
    	
    	bm = BitmapResizer.getResizedToFrame(originalBm, 240, 320);
    	tv4.setText("getResizedToFrame()\nFrame: 240x320");
    	image4.setImageBitmap(bm);
    	
    	bm = BitmapResizer.getResizedToFillFrame(originalBm, 320, 240, cuttingMode);
    	tv5.setText("getResizedToFillFrame()\nFrame: 320x240");
    	image5.setImageBitmap(bm);
    	
    	bm = BitmapResizer.getResizedToFillFrame(originalBm, 240, 320, cuttingMode);
    	tv6.setText("getResizedToFillFrame()\nFrame: 240x320");
    	image6.setImageBitmap(bm);
    }
    
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) { 
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent); 

        switch(requestCode) { 
        case SELECT_PHOTO:
            if(resultCode == RESULT_OK){  
                Uri selectedImage = imageReturnedIntent.getData();
                InputStream imageStream = null;
				try {
					imageStream = getContentResolver().openInputStream(selectedImage);
				} catch (FileNotFoundException e) {
					Toast.makeText(getApplicationContext(), e.toString(), 1).show();
				}
                Bitmap yourSelectedImage = BitmapFactory.decodeStream(imageStream);
                Toast.makeText(getApplicationContext(), "Image selected! " + yourSelectedImage.toString(), 1).show();
                
                originalBm = yourSelectedImage;
                drawImages();
            }
        }
    }
    
    
    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
    	
    	
    	menu.add("Cutting mode: NONE");
    	menu.add("Cutting mode: CENTER_HORIZONTAL");
    	menu.add("Cutting mode: CENTER_VERTICAL");
    	menu.add("Cutting mode: CENTER");
    	
    	
    	
    	menu.getItem(0).setOnMenuItemClickListener(new OnMenuItemClickListener() {
			
			public boolean onMenuItemClick(MenuItem item) {
				cuttingMode = BitmapResizer.CUT_NONE;
				drawImages();
				return false;
			}
			
		});
    	
    	menu.getItem(1).setOnMenuItemClickListener(new OnMenuItemClickListener() {
			
			public boolean onMenuItemClick(MenuItem item) {
				cuttingMode = BitmapResizer.CUT_CENTER_HORIZONTAL;
				drawImages();
				return false;
			}
			
		});
    	
    	menu.getItem(2).setOnMenuItemClickListener(new OnMenuItemClickListener() {
			
			public boolean onMenuItemClick(MenuItem item) {
				cuttingMode = BitmapResizer.CUT_CENTER_VERTICAL;
				drawImages();
				return false;
			}
			
		});
    	
    	menu.getItem(3).setOnMenuItemClickListener(new OnMenuItemClickListener() {
			
			public boolean onMenuItemClick(MenuItem item) {
				cuttingMode = BitmapResizer.CUT_CENTER;
				drawImages();
				return false;
			}
			
		});
    	
    	return super.onCreateOptionsMenu(menu);
    }
    
    
}