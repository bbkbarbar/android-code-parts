/** Automatically generated file. DO NOT MODIFY */
package hu.bandras.probafeladat.androidapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}