package hu.bandras.probafeladat;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 * Object to handle input(s).
 * 
 * @author B. Andras
 */
public class InputHandler {
	
	
	
	/**
	 * Means the size of matrix (table). 
	 */
	short rowCount, columnCount;
	
	/**
	 * Contains the original "table" from input.
	 */
	short[][] table = null;
	
	
	
	
	/**
	 * @return the number of rows.
	 */
	public short getRowCount(){
	
		return this.rowCount;
		
	}
	
	
	/**
	 * @return the number of columns.
	 */
	public short getColumnCount(){
		
		return this.columnCount;
		
	}
	
	
	/**
	 * Read file (be.txt) and process data from file. 
	 */
	public InputHandler(){
		try {
			
			
			FileInputStream fstream = new FileInputStream("be.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			
			
		    String str = br.readLine();	// Read the first line (to get row count and column count).
		    
		    getRowsAndColumns(str);
		    
		    
		    table = new short[this.rowCount][this.columnCount]; // Init matrix.
		    
		    int currentLine = 0;
		    while ((str = br.readLine()) != null) {
		    	processLine(str, currentLine);
		    	currentLine++;
		    }
		    
		    
		    in.close();
		} catch (IOException e) {
			System.out.println("IO Exception while try to read be.txt\n" + e.toString());
		}
	}

	
	// TODO: gift -eket given-re jav�tani �s ellen�rizni ford�t�ban!
	/**
	 * Read numbers of rows and columns from given string.
	 * @param str the String what contains the row count and column count.
	 * <br> (For example: "20 17")
	 */
	private void getRowsAndColumns(String str) {
		
		int idxOfSpace = str.indexOf(' ');
		
		this.rowCount = (short)(Integer.parseInt(str.substring(0, idxOfSpace)));
		this.columnCount = (short)(Integer.parseInt(str.substring(idxOfSpace + 1, str.length())));
		
	}
	
	
	/**
	 * Read the table fields from line and store them to table matrix. 
	 * @param line the line what contains the fields <br>(For example: "0 1 0 0 1 2 0 1 2 2 0 0 1").
	 * @param currentLine represents the idx of the current row (line).
	 */
	private void processLine(String line, int currentLine) {
		
		String[] elements = line.split(" ");
		
		for(int i=0; i<elements.length; i++){
			table[currentLine][i] = (byte)(Integer.parseInt(elements[i]));
		}
		
	}
	
	
	/**
	 * @return the table matrix what contains the specified fields from file.
	 */
	public short[][] getTable(){
		return this.table;
	}
	
}
