package hu.bandras.probafeladat;


/**
 * The object what contains the optimal route and the weight of that route.
 * 
 * 
 * @author Barbar
 *
 */
public class Result {
	
	
	/**
	 * the weight of route (it means the count of the penalty fields where we must step).
	 */
	private int weight;
	
	
	private String route = null;
	
	
	/**
	 * Constructor of {@linkplain Result result class}.
	 * @param weight the total weight of route.
	 * @param route a String like this: "LLJJLJJLJLL".
	 */
	public Result(int weight, String route){
		this.weight = weight;
		this.route = route;
	}

	
	
	/**
	 * @return the weight of route.
	 */
	public int getWeight() {
		return weight;
	}

	
	
	/**
	 * @return the route<br>
	 * (Like this: "LLJJLJLJLLJL")
	 */
	public String getRoute() {
		return route;
	}
	
	
	
	/**
	 * @return the route like getRoute(), but this can't returns null, <br>only can return the real route or "".
	 */
	public String getRouteStr(){
		if(route!=null)
			return route;
		else
			return "";
	}

	
	
	/**
	 * @return a String object what need to write to the output file. 
	 */
	@Override
	public String toString(){
		
			return this.weight + "\r\n" + this.getRouteStr();
			
	}
	
	
	
	/**
	 * Shows the result on standard output.
	 */
	public void show(){
		
		System.out.println("Total weight of best route: " + this.weight);
		System.out.println(this.getRouteStr());
		
	}
	
	
	
}
