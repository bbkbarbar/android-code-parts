package hu.bandras.probafeladat;

/**
 * Class to store vertices of graph.
 * 
 * 
 * @author Barbar
 *
 */
public class Vertex {
	
	
	/**
	 * This means the total weight of route to right-bottom corner of table FROM THIS POINT of graph. 
	 */
	private int weight;
	
	
	/**
	 * It shows where we need to go from here.	
	 */ 	// TODO: az angol ford�t�s�t megn�zni ennek.
	private char arrow;
	
	
	
	/**
	 * Constructor of Vertex object.
	 * @param weight means the total weight of route to right-bottom corner of table FROM THIS POINT of graph.
	 * @param arrow shows where we need to go from this point.
	 */
	public Vertex(int weight, char arrow){
		this.weight = weight;
		this.arrow = arrow;
	}

	
	//TODO: kommentet �rni a getF�ggv�nyekhez (vagy �tgondolni, hogy oda kell-e)...
	
	
	/**
	 * @return the weight of point of graph.<br>
	 * (The weight of point means the weight of the route until finish point.) 
	 */
	public int getWeight() {
		return weight;
	}
	
	


	/**
	 * @return the char what shows "where need to go.."
	 */
	public char getArrow() {
		return arrow;
	}
	
	
	
	/**
	 * @return a String to show vertices of graph.
	 */
	public String toString(){
		
		String w;
		
		if(this.weight>=0)
			w = Integer.toString(this.weight);
		else
			w = "X";
		
		return w + this.arrow;
		
	}


	
	
	
	/**
	 * Decrease the weight of the [0,0] point of graph.<br>
	 * (The starting point for penalty field then it should not be included in the total weight of the path.)
	 */
	public void decreaseWeight() {
		
		this.weight--;
		
	}
	
	
	
	
	
}
