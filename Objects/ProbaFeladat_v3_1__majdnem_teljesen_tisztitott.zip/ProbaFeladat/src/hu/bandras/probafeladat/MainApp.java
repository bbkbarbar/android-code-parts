package hu.bandras.probafeladat;


public class MainApp {

	
	/**
	 * Contains the original "table" from input.
	 */
	private short[][] table;
	
	/**
	 * Means the size of matrix (table). 
	 */
	private short rowCount, columnCount;
	
	
	
	public static void main(String[]  args){
		
		MainApp app = new MainApp();
		
		app.start();
		
	}
	
	
	/**
	 * Run app..
	 */
	private void start() {
		
		this.getTable();
		
		Result result = RouteFinder.findRoute(rowCount, columnCount, table);
		
		OutputHandler.writeOutput(result);
		
	}
	
	
	
	/**
	 * Read table from input.
	 */
	private void getTable(){
		
		InputHandler myInputHandler = new InputHandler();
		this.table = myInputHandler.getTable();
		this.rowCount = myInputHandler.getRowCount();
		this.columnCount = myInputHandler.getColumnCount();
		
	}

	
}
