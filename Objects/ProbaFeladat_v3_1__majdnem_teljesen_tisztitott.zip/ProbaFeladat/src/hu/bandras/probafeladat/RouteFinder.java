package hu.bandras.probafeladat;


/**
 * Object what contains the functions to find optimal route.
 * 
 * @author B. Andras
 *
 */
public class RouteFinder {

	
	
	/**
	 * Find the optimal route between 0,0 point and the right bottom corner of table.
	 * @param row the number of rows.
	 * @param column the number of columns.
	 * @param table the matrix which contains the fields.
	 * @return a Result object which contains the weight of optimal route, and the contains the route (like this: "JJLJLJJLJJJJJLJL").
	 */
	public static Result findRoute(short rowCount, short columnCount, short[][] table){
		
		Vertex[][] graph = RouteFinder.buildGraph(rowCount, columnCount, table);
		
		return RouteFinder.getResultFromGraph(graph, rowCount, columnCount);
		
	}
	

	
	/**
	 * @param rowCount
	 * @param columnCount
	 * @param table
	 * @return the directed graph what created from table and what contains the weights of different routes (what shows the optimal route).
	 */
	private static Vertex[][] buildGraph(short rowCount, short columnCount, short[][] table){
		
		Vertex[][] graph = new Vertex[rowCount][columnCount];
		
		short cColumn, cRow, startColumn, startRow;
		
		startColumn = (short) (columnCount-1);
		startRow = (short) (rowCount-1);
		
		cColumn = startColumn;
		cRow = startRow;
		
		
		while( (startRow>=0) && (startColumn>=0) ){
			
			
			// Examine the neighbor fields
			
			boolean hasBottomNeighbor = false;
			boolean hasRightNeighbor = false;
			
			if(cRow < (rowCount -1))
				hasBottomNeighbor = true;
			
			
			if(cColumn < (columnCount -1))
				hasRightNeighbor = true;
			
			
			
			boolean bottomNeighborIsTrap = false;
			boolean rightNeighborIsTrap = false;
			
			if(hasBottomNeighbor){
				if(graph[cRow+1][cColumn].getWeight() < 0){
					bottomNeighborIsTrap = true;
				}
			}
			
			if(hasRightNeighbor){
				if(graph[cRow][cColumn+1].getWeight() < 0){
					rightNeighborIsTrap = true;
				}
			}
			
			
			
			// Init the temp variables.
			
			int weightOfCurrentPoint = 0;
			char arrow = '-';
			
			
			
			// Calculate the weight of current field.
			
			if(table[cRow][cColumn] == 2){	// the current field is a trap..
				
				arrow = 'X';
				weightOfCurrentPoint = -1;
				
			}else{	// the current field is NOT a trap..
				
				if( (cRow == (rowCount-1)) && (cColumn == (columnCount-1)) ){ // the current field is the goal..
					
					arrow = ' ';
					weightOfCurrentPoint = table[cRow][cColumn];
					
				}else{	// need to calculate the weight of current field..
			
					if(hasRightNeighbor && hasBottomNeighbor){
						
						if(!bottomNeighborIsTrap && !rightNeighborIsTrap){	// necessary to look at where is the cheaper way.
							
							if(graph[cRow+1][cColumn].getWeight() < graph[cRow][cColumn+1].getWeight()){ // the bottom neighbor's weight is less.
								
								arrow = 'L';
								weightOfCurrentPoint = table[cRow][cColumn] + graph[cRow+1][cColumn].getWeight();
								
							}else{	// the right sided neighbor's weight is less.
								
								arrow = 'J';
								weightOfCurrentPoint = table[cRow][cColumn] + graph[cRow][cColumn+1].getWeight();
								
							}
							
						}else
							
						if(bottomNeighborIsTrap && !rightNeighborIsTrap){	// the only way is the right side.	
							
							arrow = 'J';
							weightOfCurrentPoint = table[cRow][cColumn] + graph[cRow][cColumn+1].getWeight();
							
						}else
						
						if(!bottomNeighborIsTrap && rightNeighborIsTrap){	// the only way is down.
							
							arrow = 'L';
							weightOfCurrentPoint = table[cRow][cColumn] + graph[cRow+1][cColumn].getWeight();
							
						}else{	// ..so we can move only to a trap from here.
						
							arrow = 'X';
							weightOfCurrentPoint = -1;	
							
						}	
						
					}else
					
					if(!hasRightNeighbor && hasBottomNeighbor){	// ..have no right sided neighbor.
						
						if(bottomNeighborIsTrap){
							
							arrow = 'X';
							weightOfCurrentPoint = -1;
							
						}else{
							
							arrow = 'L';
							weightOfCurrentPoint = table[cRow][cColumn] + graph[cRow+1][cColumn].getWeight();
							
						}
						
					}else
					
					if(hasRightNeighbor && !hasBottomNeighbor){	// ..have no borrom neighbor.
						
						if(rightNeighborIsTrap){
							
							arrow = 'X';
							weightOfCurrentPoint = -1;
							
						}else{
							
							arrow = 'J';
							weightOfCurrentPoint = table[cRow][cColumn] + graph[cRow][cColumn+1].getWeight();
							
						}
						
					}
				}
			
			}
			
			
			//Store the new vertex..
			
			graph[cRow][cColumn] = new Vertex(weightOfCurrentPoint, arrow);
			
			
			
			
			// Calculate which will be the next field what we need to examine.
			
			
			if( ((cRow-1) >= 0) && ((cColumn+1) < columnCount) ){ // we can step one right and up
				
				cRow--;
				cColumn++;
				
			}else{	// we need to start a new "diagonal line" on a new column or row
				
				if(startColumn > 0){ // even go to the left on the last row.
					
					startColumn--;
					
				}else{	// we are on the first column on last row , so we need to step up.
					
					if(startRow>=0)	 
						startRow--;
					
				}
				
				
				 // Set cRow and cColumn to start a new diagonal line.
				
				cRow = startRow;
				cColumn = startColumn;
				
			}
			
			
		}
		
		
		
		//	If the starting point is a "penalty field" then it should not be included in the total weight of the path.
		
		if(table[0][0]==1){
			graph[0][0].decreaseWeight();
		}
		
		
		return graph;
		
	}

	
	
	/**
	 * Go through on the graph and record the optimal path.
	 * @param graph
	 * @param rowCount
	 * @param columnCount
	 * @return the {@linkplain Result result object} what contains the result of route finding.  
	 */
	private static Result getResultFromGraph(Vertex[][] graph, short rowCount, short columnCount){
		
		String route = "";
		
		short cRow = 0, cColumn = 0;
		
		while( (cRow < rowCount-1) || (cColumn < columnCount-1) ){
			route += graph[cRow][cColumn].getArrow();
			
			if(graph[cRow][cColumn].getArrow() == 'J'){
				cColumn++;
			}else
				
			if(graph[cRow][cColumn].getArrow() == 'L'){
				cRow++;
			}
			else{
				return new Result(-1, null);
			}
		}
		
		return new Result(graph[0][0].getWeight(), route);
		
	}
	
	
	
}
