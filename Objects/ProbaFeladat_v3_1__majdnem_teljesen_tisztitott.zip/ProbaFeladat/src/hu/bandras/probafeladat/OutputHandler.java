package hu.bandras.probafeladat;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class OutputHandler {

	
	public static final String OUTPUT_FILE = "ki.txt";
	
	
	
	/**
	 * Write the given Result object to output file.
	 * @param resultToWrite the Result object.
	 * @return <b>true</b> if data wrote successfully<br>
	 * else <b>false</b> if could not write data.
	 */
	public static boolean writeOutput(Result resultToWrite){
		
		try{
			
			PrintWriter out = new PrintWriter(new FileWriter(OUTPUT_FILE));
			
			out.println(
						Integer.toString(resultToWrite.getWeight()) 
						+ "\r\n"
						+ resultToWrite.getRouteStr()
					);
			
			out.close();
			
		}catch(IOException exc){
			
			System.err.println("IO Exception caught while try to write output file (" + OUTPUT_FILE + ").");
			exc.printStackTrace();
			
			return false;
			
		}catch(Exception e){
			
			System.err.println("Exception caught while try to write output file (" + OUTPUT_FILE + ")!");
			System.err.println("Error: " + e.getMessage());
			
			return false;
		}
		
		return true;
		
	}
	
	
	
	/*
	public static boolean writeGraph(Vertex[][] graph, short row, short column, String filename){
		
		try{
			
			PrintWriter out = new PrintWriter(new FileWriter(filename));
			
			for(int i=0; i<row; i++){
				for(int j=0; j<column; j++){
					
					if(graph[i][j].getWeight()==(-1)){
						
						out.print("X" + graph[i][j].getArrow() + " ");
						
					}else
						out.print(
									Integer.toString(graph[i][j].getWeight())
									+ graph[i][j].getArrow() + " "
								 );
					
				}
				out.println("");
			}
			
			out.close();
			
		}catch(IOException exc){
			
			System.err.println("IO Exception caught while try to write graph to text file.");
			exc.printStackTrace();
			
			return false;
		}
		
		return true;
	}	/**/
	
	
}
