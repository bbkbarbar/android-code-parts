package hu.bandras.probafeladat.androidapp;

import hu.bandras.probafeladat.*;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class ProbaFeladatActivity extends Activity {

	// UI elements
	
	private EditText fileNameEdit;
	private Button openFileBtn, findRouteBtn;
	private TextView msgTV;
	
	
	// Variables to store the table
	 
	private short[][] table;
	private short rowCount, columnCount;
	
	
	// Other variables
	
	private boolean tableLoaded = false;
	
	
	
	/**
	 * This method called when activity started.
	 */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        
        initUI();
        
    }
    
    
    
    /**
     * Initialize the elements of UI.
     */
    private void initUI(){
    	
    	fileNameEdit = (EditText) findViewById(R.id.edit_filename);
    	
        openFileBtn = (Button) findViewById(R.id.open_file_button);
        openFileBtn.setOnClickListener(new OnClickListener(){

			public void onClick(View v) {
				
				readFile();	
				
			}
        	
        });
        
        msgTV = (TextView) findViewById(R.id.msg);
        
        findRouteBtn = (Button) findViewById(R.id.find_route_button);
        findRouteBtn.setEnabled(false);
        findRouteBtn.setOnClickListener(new OnClickListener() {
			
			public void onClick(View arg0) {
				
				if(tableLoaded)
					calcRouteAndShowResult();
				
			}
		});
        
    }
    
    
    
    /**
     * Read the input from file.
     */
    private void readFile(){
    	
    	InputHandlerForAndroid myIH = new InputHandlerForAndroid(fileNameEdit.getText().toString());
    	
    	if(myIH.isInputSuccessfullReaded()){
    	
    		rowCount = myIH.getRowCount();
    		columnCount = myIH.getColumnCount();
    		table = myIH.getTable();
    		
    		msgTV.setText("File opened!\nRow: " + rowCount + " Column: " + columnCount);
    		
    		tableLoaded = true;
    	
    	}else{
    		
    		tableLoaded = false;
    		Toast.makeText(getApplicationContext(), "File not readed!", Toast.LENGTH_SHORT).show();
    		
    	}
    	
    	findRouteBtn.setEnabled(tableLoaded);
    	
    }
    
    
    
    /**
     * Calculate the optimal route and show result.
     */
    private void calcRouteAndShowResult(){
    	
    	long startTime = System.currentTimeMillis();
    	long endTime;
    	
    	Result res = RouteFinder.findRoute(rowCount, columnCount, table);
    	
    	endTime = System.currentTimeMillis();
    	
    	msgTV.setText(	
    					"Input:\nRow: " + rowCount + " Column: " + columnCount +
    					"\nResult:\n" +
						Integer.toString(res.getWeight()) + "\n" +
						res.getRoute() +
						"\n\nElasped time: " + Double.toString((double)((double)(endTime-startTime)/1000)) + " s"
					);
    	
    }
    

    
    /**
     * Auto generated method for show menu.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //getMenuInflater().inflate(R.menu.main_activity, menu);
        //return true;
    	return false;
    }
    
    
    
}
