package hu.bandras.probafeladat.androidapp;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import android.os.Environment;


public class InputHandlerForAndroid {

	

	/**
	 * Means the size of matrix (table). 
	 */
	short rowCount, columnCount;
	
	/**
	 * Contains the original "table" from input.
	 */
	short[][] table = null;
	
	
	private boolean isInputSuccessfullReaded = false;
	
	
	
	
	public short[][] getTable(){
		
		return this.table;
	}
	
	
	
	public boolean isInputSuccessfullReaded(){
		
		return isInputSuccessfullReaded;
		
	}
	
	

	/**
	 * @return the number of rows.
	 */
	public short getRowCount(){
	
		return this.rowCount;
		
	}
	
	
	/**
	 * @return the number of columns.
	 */
	public short getColumnCount(){
		
		return this.columnCount;
		
	}
	
	
	
	
	public InputHandlerForAndroid(String filename){
		
		//Find the directory for the SD Card using the API
		File sdcard = Environment.getExternalStorageDirectory();

		//Get the text file
		File file = new File(sdcard,filename);

		try {
		    BufferedReader br = new BufferedReader(new FileReader(file));
		    
		    String line = br.readLine();
		    
		    getRowsAndColumns(line);
		    
		    table = new short[this.rowCount][this.columnCount]; // Init matrix.

		    int currentLine = 0;
		    while ((line = br.readLine()) != null) {
		    	processLine(line, currentLine);
		    	currentLine++;
		    }
		    
		    br.close();
		 
		    isInputSuccessfullReaded = true;
		}
		catch (IOException e) {
		    
		}
		
	}

	
	
	
	/**
	 * Read numbers of rows and columns from given string.
	 * @param str the String what contains the row count and column count.
	 * <br> (For example: "20 17")
	 */
	private void getRowsAndColumns(String str) {
		
		int idxOfSpace = str.indexOf(' ');
		
		this.rowCount = (short)(Integer.parseInt(str.substring(0, idxOfSpace)));
		this.columnCount = (short)(Integer.parseInt(str.substring(idxOfSpace + 1, str.length())));
		
	}
	
	
	
	/**
	 * Read the table fields from line and store them to table matrix. 
	 * @param line the line what contains the fields <br>(For example: "0 1 0 0 1 2 0 1 2 2 0 0 1").
	 * @param currentLine represents the idx of the current row (line).
	 */
	private void processLine(String line, int currentLine) {
		
		String[] elements = line.split(" ");
		
		for(int i=0; i<elements.length; i++){
			table[currentLine][i] = (byte)(Integer.parseInt(elements[i]));
		}
		
	}
	
	
}
